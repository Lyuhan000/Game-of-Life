package gol

import (
	"fmt"
	"sync"
	"time"
	"uk.ac.bris.cs/gameoflife/util"
)

type distributorChannels struct {
	events     chan<- Event
	ioCommand  chan<- ioCommand
	ioIdle     <-chan bool
	ioFilename chan<- string
	ioOutput   chan<- uint8
	ioInput    <-chan uint8
	keyPress   <-chan rune
}

const (
	CURRENT = iota
	OLD
)

type world struct {
	grid     [][]byte
	oldgrid  [][]byte
	params   *Params
	events   chan<- Event
	command  chan<- ioCommand
	filename chan<- string
	input    <-chan uint8
	output   chan<- uint8
}

// distributor divides the work between workers and interacts with other goroutines.
func distributor(p Params, c distributorChannels) {
	// TODO: Create a 2D slice to store the world.

	infile := fmt.Sprintf("%dx%d", p.ImageHeight, p.ImageWidth)
	outfile := fmt.Sprintf("%dx%dx%d", p.ImageHeight, p.ImageWidth, p.Turns)

	w := newWorld(&p, c)

	w.load(infile)

	turn := 0
	aliveCount := w.getAliveCount()
	go func() {
		timer := time.NewTicker(2 * time.Second)
		for turn < p.Turns {
			<-timer.C
			if turn >= p.Turns-1 {
				timer.Stop()
				break
			}
			c.events <- AliveCellsCount{CompletedTurns: turn, CellsCount: aliveCount}
		}
	}()

	group := sync.WaitGroup{}
	// Execute all turns of the Game of Life.
	totGridNum := p.ImageHeight * p.ImageWidth
	partGridNum := totGridNum / p.Threads
	remainGridNum := totGridNum % p.Threads
turnsLoop:
	for ; turn < p.Turns; turn++ {
		startGridIdx := 0
		group.Add(p.Threads)
		w.copyOldGrid()
		for i := 0; i < p.Threads; i++ {
			endsGridIdx := startGridIdx + partGridNum
			if i+1 == p.Threads {
				endsGridIdx += remainGridNum
			}
			go func(start, ends int) {
				defer group.Done()
				// rpc call <- resp
				w.parallelIterate(start, ends)
			}(startGridIdx, endsGridIdx)
			startGridIdx += partGridNum
		}
		group.Wait()
		aliveCount = w.getAliveCount()
		c.events <- TurnComplete{CompletedTurns: turn}
		isPaused := false
	keyPressLoop:
		for {
			select {
			case keyPress := <-c.keyPress:
				if keyPress == 's' && !isPaused {
					w.save(fmt.Sprintf("%dx%dx%d", p.ImageHeight, p.ImageWidth, turn))
				} else if keyPress == 'q' && !isPaused {
					w.save(fmt.Sprintf("%dx%dx%d", p.ImageHeight, p.ImageWidth, turn))
					break turnsLoop
				} else if keyPress == 'p' {
					isPaused = !isPaused
					if isPaused {
						c.events <- AliveCellsCount{CompletedTurns: turn, CellsCount: aliveCount}
					} else if !isPaused {
						fmt.Println("Continuing")
					}
				}
			default:
				if !isPaused {
					break keyPressLoop
				}
			}
		}
	}
	// Report the final state using FinalTurnCompleteEvent.
	var cells []util.Cell
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if w.get(x, y, CURRENT) {
				cells = append(cells, util.Cell{X: x, Y: y})
			}
		}
	}
	c.events <- FinalTurnComplete{turn, cells}

	// save pgm to file
	w.save(outfile)

	// Make sure that the Io has finished any output before exiting.
	c.ioCommand <- ioCheckIdle
	<-c.ioIdle

	c.events <- StateChange{turn, Quitting}

	// Close the channel to stop the SDL goroutine gracefully. Removing may cause deadlock.
	close(c.events)
}

func (w *world) copyOldGrid() {
	w.oldgrid = make([][]byte, w.params.ImageHeight)
	for i := range w.oldgrid {
		w.oldgrid[i] = make([]byte, w.params.ImageWidth)
		copy(w.oldgrid[i], w.grid[i])
	}
}

func newWorld(p *Params, c distributorChannels) *world {
	g := make([][]byte, p.ImageHeight)
	for i := range g {
		g[i] = make([]byte, p.ImageWidth)
	}

	return &world{
		grid:     g,
		oldgrid:  nil,
		params:   p,
		events:   c.events,
		command:  c.ioCommand,
		filename: c.ioFilename,
		input:    c.ioInput,
		output:   c.ioOutput,
	}
}

// load the world from a file
func (w *world) load(filename string) {
	w.command <- ioInput
	w.filename <- filename

	for y := 0; y < w.params.ImageHeight; y++ {
		for x := 0; x < w.params.ImageWidth; x++ {
			val := <-w.input
			w.grid[y][x] = val
			if val != 0 {
				w.events <- CellFlipped{Cell: util.Cell{X: x, Y: y}}
			}
		}
	}
}

// save the world to a file
func (w *world) save(filename string) {
	w.command <- ioOutput
	w.filename <- filename
	for y := 0; y < w.params.ImageHeight; y++ {
		for x := 0; x < w.params.ImageWidth; x++ {
			w.output <- w.grid[y][x]
		}
	}

	w.events <- ImageOutputComplete{CompletedTurns: w.params.Turns, Filename: filename}
}

// check if a cell is within the grid
func (w *world) checkin(x, y int) bool {
	if x < 0 || x >= w.params.ImageWidth || y < 0 || y >= w.params.ImageHeight {
		return false
	}
	return true
}

// set a cell state (alive: 255, dead: 0)
func (w *world) set(x, y int, val byte) {
	if w.checkin(x, y) {
		w.grid[y][x] = val
		w.events <- CellFlipped{Cell: util.Cell{X: x, Y: y}}
	}
}

// get a cell state (alive: true, dead: false)
func (w *world) get(x, y, world int) bool {
	if w.checkin(x, y) {
		if world == CURRENT {
			return w.grid[y][x] != 0
		} else {
			return w.oldgrid[y][x] != 0
		}
	}
	return false
}

// get the number of neighbours of a cell
func (w *world) neighbours(x, y int) int {
	if !w.checkin(x, y) {
		return 0
	}

	var n int = 0
	directions := []int{-1, 0, 1}
	for _, dx := range directions {
		for _, dy := range directions {
			if dx == 0 && dy == 0 {
				continue
			}
			if w.get(x+dx, y+dy, OLD) {
				n++
			}
		}
	}

	// consider the cell grid to be on a closed domain
	//  pixels on the left are connected to pixels on the right or left
	if x == 0 || x == w.params.ImageWidth-1 {
		for _, dy := range directions {
			if w.get(w.params.ImageWidth-x-1, y+dy, OLD) {
				n++
			}
		}
	}

	// pixels on the bottom row are connected to pixels at the top or bottom row
	if y == 0 || y == w.params.ImageHeight-1 {
		for _, dx := range directions {
			if w.get(x+dx, w.params.ImageHeight-y-1, OLD) {
				n++
			}
		}
	}

	return n
}

// iterate the world
func (w *world) iterate() {
	// copy the current grid to the old grid
	w.oldgrid = make([][]byte, w.params.ImageHeight)
	for i := range w.oldgrid {
		w.oldgrid[i] = make([]byte, w.params.ImageWidth)
		copy(w.oldgrid[i], w.grid[i])
	}

	for y := 0; y < w.params.ImageHeight; y++ {
		for x := 0; x < w.params.ImageWidth; x++ {
			if w.get(x, y, OLD) { //any live cell with fewer than two live neighbours dies.
				if w.neighbours(x, y) < 2 || w.neighbours(x, y) > 3 { //any live cell with more than three live neighbours dies.
					w.set(x, y, 0)
				}
				//any live cell with two or three live neighbours is unaffected.
			} else {
				if w.neighbours(x, y) == 3 {
					w.set(x, y, 255)
				}
			}
		}
	}
	w.oldgrid = nil
}

func (w *world) getRowAndCol(idx int) (x, y int) {
	x = idx / w.params.ImageWidth
	y = idx % w.params.ImageWidth
	return x, y
}

//left closed domain  right open
func (w *world) parallelIterate(startIdx, endsIdx int) {
	for idx := startIdx; idx < endsIdx; idx++ {
		x, y := w.getRowAndCol(idx)
		if w.get(x, y, OLD) { //any live cell with fewer than two live neighbours dies.
			if w.neighbours(x, y) < 2 || w.neighbours(x, y) > 3 { //any live cell with more than three live neighbours dies.
				w.set(x, y, 0)
			}
			//any live cell with two or three live neighbours is unaffected.
		} else {
			if w.neighbours(x, y) == 3 {
				w.set(x, y, 255)
			}
		}
	}
}

func (w *world) getAliveCount() int {
	var count int = 0
	for y := 0; y < w.params.ImageHeight; y++ {
		for x := 0; x < w.params.ImageWidth; x++ {
			if w.get(x, y, CURRENT) {
				count++
			}
		}
	}
	return count
}
